﻿// Copyright Anton Vasserman, All Rights Reserved.

#include "Logging/AV_LogAVUtilitiesCommonUI.h"

DEFINE_LOG_CATEGORY(AV_LogAVUtilitiesCommonUI);
