﻿// Copyright Anton Vasserman, All Rights Reserved.

#pragma once

#include "Logging/LogMacros.h"

DECLARE_LOG_CATEGORY_EXTERN(AV_LogAVUtilitiesCommonUI, Log, All);
