﻿// Copyright Anton Vasserman, All Rights Reserved.

#pragma once

#include "Logging/LogMacros.h"

AVCHARACTERFALL_API DECLARE_LOG_CATEGORY_EXTERN(LogAV_CharacterFall, Log, All);
