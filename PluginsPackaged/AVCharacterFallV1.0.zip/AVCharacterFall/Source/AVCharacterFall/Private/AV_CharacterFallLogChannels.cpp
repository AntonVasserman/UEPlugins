﻿// Copyright Anton Vasserman, All Rights Reserved.

#include "AV_CharacterFallLogChannels.h"

DEFINE_LOG_CATEGORY(LogAV_CharacterFall);
